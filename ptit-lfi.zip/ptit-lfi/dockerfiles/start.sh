#!/bin/bash
ncat -nlvp 9999 -k -e ./lfi_vuln.sh &
